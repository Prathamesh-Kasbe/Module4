var traineeModule = angular.module("traineeModule",[]);   //place to set the dependency

traineeModule.controller("traineesController",
	function($scope){
		$scope.trainees = [
		                  {
							'traineeId'   : 'A001',
							'traineeName' : 'Name Please',
							'domain'      : 'java',
							'location'    : 'mumbai'
		                  },
		                  {
							'traineeId'   : 'A002',
							'traineeName' : 'Name Please',
							'domain'      : '.net',
							'location'    : 'pune'
			              },
			              {
							'traineeId'   : 'A003',
							'traineeName' : 'Name Please',
							'domain'      : 'testing',
							'location'    : 'chennai'
			              }
		 ];
		$scope.domains = [
		                  'Java','Dotnet','Python','Scala' 
		];
		$scope.locations = [
		                  'Pune','Mumbai','Bengluru','Gurugram','Kolkata','Noida','Hyderabad' 
		];
	}
);

traineeModule.controller("traineeController",
			function($scope){
				$scope.trainee={
						'traineeName':'Name Please',
						'domain'     :'',
						'location'   :''
				};
				$scope.domains = [
				                  'Java','Dotnet','Python','Scala' 
				];
				$scope.locations = [
				                  'Pune','Mumbai','Bengluru','Gurugram','Kolkata','Noida','Hyderabad' 
				];
			}
);