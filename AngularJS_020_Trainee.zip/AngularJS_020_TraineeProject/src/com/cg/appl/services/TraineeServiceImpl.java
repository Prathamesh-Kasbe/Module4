package com.cg.appl.services;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.cg.appl.daos.TraineeDao;
import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeException;

@Service("traineeService")
public class TraineeServiceImpl implements TraineeService {

	private TraineeDao dao;
	
	@Resource(name="traineeDao")
	public void setDao(TraineeDao dao) {
		this.dao = dao;
	}

	@Override
	public Trainee getTraineeDetails(int traineeId) throws TraineeException {
		return dao.getTraineeDetails(traineeId);
	}

	@Override
	public List<Trainee> getAllTrainees() throws TraineeException {
		return dao.getAllTrainees();
	}

	@Override
	public Trainee addNewTrainee(Trainee trainee) throws TraineeException {
		return dao.addNewTrainee(trainee);
	}

	@Override
	public Trainee updateTrainee(Trainee trainee) throws TraineeException {
		return dao.updateTrainee(trainee);
	}

}
