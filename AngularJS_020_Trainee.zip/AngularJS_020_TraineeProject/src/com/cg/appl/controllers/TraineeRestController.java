package com.cg.appl.controllers;

import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeException;
import com.cg.appl.services.TraineeService;

//http://localhost:8085/AngularJS_020_TraineeProject/trainees.do
@RestController
public class TraineeRestController {
	private TraineeService service;
	
	public void setService(TraineeService service){
		this.service=service;
	}
	
	@RequestMapping(value="/trainees",method=RequestMethod.GET,headers="Accept=application/json")
	public List<Trainee> getAllTrainees() throws TraineeException{
		return service.getAllTrainees();
		
	}
	
}