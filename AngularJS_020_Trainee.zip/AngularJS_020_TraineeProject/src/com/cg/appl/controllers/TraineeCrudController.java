package com.cg.appl.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeException;
import com.cg.appl.services.TraineeService;

//http://localhost:8085/Spring110MVC_Basic/welcome.do
@Controller
public class TraineeCrudController {   

	private TraineeService service;
	private List<String> domainList;
	private List<String> locations;
	
	@Resource(name="traineeService")
	public void setTraineeService(TraineeService service){
		this.service=service;
	}
	
	@PostConstruct
	public void initialize(){
		domainList = new ArrayList<>();
		domainList.add("Java");
		domainList.add("DotNet");
		domainList.add("Database");
		domainList.add("Analytics");
		
		locations = new ArrayList<>();
		locations.add("Pune");
		locations.add("Mumbai");
		locations.add("Benglure");
		locations.add("Kolkata");
		locations.add("Delhi");
	}
	
	@RequestMapping("/enterTraineeNo.do")
	public ModelAndView enterTraineeNo(){
	ModelAndView model = new ModelAndView("enterTraineeNo");
	return model;
    }
	
	@RequestMapping("/getTraineeDetails.do")
	public ModelAndView getTraineeDetails(@RequestParam("traineeNo") int traineeNo){
	Trainee trainee;
	ModelAndView model=null;
	try {
		trainee = service.getTraineeDetails(traineeNo);
		model = new ModelAndView("traineeDetails");
		model.addObject("traineeDetails",trainee);
	} catch (TraineeException e) {
		model.addObject("errorMsg",e.getMessage());
		model = new ModelAndView("error");
	}
	
	return model;
    }
	
	@RequestMapping("/listAllTrainees.do")
	public ModelAndView listAllTrainees(){
	ModelAndView model=null;
	List<Trainee> trainees=new ArrayList<>();
	try{
		trainees=service.getAllTrainees();
	model = new ModelAndView("traineesList");
	model.addObject("trainees",trainees);
	}catch (TraineeException e) {
		model.addObject("errorMsg",e.getMessage());
		model = new ModelAndView("error");
	}
	return model;
    }
	
	@RequestMapping("/welcome.do")
	public ModelAndView getLoginPage(){
	ModelAndView model = new ModelAndView("welcome");
	return model;
    }
	
	@RequestMapping("/getEntryForm.do")
	public ModelAndView getEntryForm(){
	ModelAndView model = new ModelAndView("entryForm");
	model.addObject("trainee",new Trainee());
	model.addObject("domains",domainList);
	model.addObject("locations",locations);
	return model;
    }

	@RequestMapping("/submitEntryForm.do")
		public ModelAndView submitEntryform(@ModelAttribute @Valid Trainee trainee, BindingResult result){
		ModelAndView model=new ModelAndView();
		if(result.hasErrors()){
			System.out.println(result.getAllErrors());
			model.addObject("trainee",new Trainee());
			model.addObject("domains",domainList);
			model.addObject("locations",locations);
			model.setViewName("entryForm");
			return model;
		}
		try {
			Trainee traineeResponse = service.addNewTrainee(trainee);
			model.setViewName("successInsert");
			model.addObject("trainee",traineeResponse);
		} catch (TraineeException e) {
			model.setViewName("error");
			model.addObject("errorMsg","Record Insertion failed: "+e.getMessage());
		}
		return model;
	}

	/*@RequestMapping("/updateTrainee.do")
	public ModelAndView updateTrainee(@RequestParam("id") int traineeNo){
	Trainee trainee;
	ModelAndView model=new ModelAndView();
	model.setViewName("error");
	model.addObject("errorMsg","dummy msg");
	try {
		trainee = service.getTraineeDetails(traineeNo);
		model = new ModelAndView("traineeDetails");
		model.addObject("traineeDetails",trainee);
	} catch (TraineeException e) {
		model.addObject("errorMsg",e.getMessage());
		model = new ModelAndView("error");
	}
	
	return model;
    }*/
	
	@RequestMapping("/getTraineeNo.do")
	public ModelAndView getTraineeNo(){
	ModelAndView model = new ModelAndView("getTraineeNoToUpdate");
	return model;
    }
	
	@RequestMapping("/updateTrainee.do")
	public ModelAndView updateTrainee(@RequestParam("traineeId") int traineeNo){
		Trainee trainee;
		ModelAndView model=null;
		try {
			trainee = service.getTraineeDetails(traineeNo);
			model = new ModelAndView("updateTrainee");
			model.addObject("trainee",trainee);
			model.addObject("domains",domainList);
			model.addObject("locations",locations);
		} catch (TraineeException e) {
			model.addObject("errorMsg",e.getMessage());
			model = new ModelAndView("error");
		}
		
		return model;
}
	
	@RequestMapping("/successUpdate.do")
	public ModelAndView successUpdate(@ModelAttribute @Valid Trainee trainee, BindingResult result){
	ModelAndView model=new ModelAndView();
	try {
		Trainee traineeResponse = service.updateTrainee(trainee);
		model.setViewName("successUpdate");
		model.addObject("trainee",traineeResponse);
	} catch (TraineeException e) {
		model.setViewName("error");
		model.addObject("errorMsg","Record Insertion failed: "+e.getMessage());
	}
	return model;
}
}

