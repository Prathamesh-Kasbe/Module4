package com.cg.empDir.services;

import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.empDir.daos.EmployeeDao;
import com.cg.empDir.entities.Employee;
import com.cg.empDir.exceptions.EmpException;

@Service("employeeService")
@Transactional
public class EmployeeServiceImpl implements EmployeeService {

   private EmployeeDao dao;
	
	@Resource(name="employeeDao")
	public void setDao(EmployeeDao dao) {
		this.dao = dao;
	}
	
	@Override
	public Employee addNewEmployee(Employee employee) throws EmpException {
		return dao.addNewEmployee(employee);
	}

	@Override
	public List<Employee> getAllEmployees() throws EmpException {
		return dao.getAllEmployees();
	}

	

}
