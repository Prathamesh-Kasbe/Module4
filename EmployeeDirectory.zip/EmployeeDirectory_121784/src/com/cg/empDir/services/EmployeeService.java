package com.cg.empDir.services;

import java.util.List;

import com.cg.empDir.entities.Employee;
import com.cg.empDir.exceptions.EmpException;

public interface EmployeeService {
	
	Employee addNewEmployee(Employee employee)throws EmpException;
	
	List<Employee> getAllEmployees()throws EmpException;
}
