package com.cg.empDir.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Required;




@SequenceGenerator(name="emp_generate", sequenceName="HIBERNATE_SEQUENCE", allocationSize=1, initialValue=1000)
@Entity(name="emp")
@Table(name="EMPLOYEE")
public class Employee implements Serializable{

	private static final long serialVersionUID = 1L;
	private int empId;
	private String empName;
	private String gender;
	private String designation;
	private String email;
	private String phone;
	
	@Id
    @GeneratedValue(generator="emp_generate", strategy=GenerationType.SEQUENCE)
	@Column(name="EMPLOYEE_CODE")
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	
	@NotEmpty(message="Name is required")
	@Size(min=1,max=40,message="Name must be of size 1 to 40") 
	@Column(name="EMPLOYEE_NAME")
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	
	@Required
	@Column(name="EMPLOYEE_GENDER")
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	@NotEmpty(message="Designation Name is required")
	@Column(name="DESIGNATION_NAME")
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	
	@NotEmpty(message="Email is required")
	@Email
	@Column(name="EMPLOYEE_EMAIL")
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@NotEmpty(message="Phone number is required")
	@Pattern(regexp="[1-9]{1}[0-9]{9}",message="invalid phone number. number should be of 10 digits")
	@Column(name="EMPLOYEE_PHONE")
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName
				+ ", gender=" + gender + ", designation=" + designation
				+ ", email=" + email + ", phone=" + phone + "]";
	}
	

	
	
	
}
