package com.cg.empDir.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.empDir.entities.Employee;
import com.cg.empDir.exceptions.EmpException;
import com.cg.empDir.services.EmployeeService;


@Controller
public class EmployeeCrudController {

	private EmployeeService service;
	private List<String> designationList;
	
	@Resource(name="employeeService")
	public void setEmpService(EmployeeService service){
		this.service=service;
	}
	
	@PostConstruct
	public void initialize(){
		designationList = new ArrayList<>();
		designationList.add("Software Engineer");
		designationList.add("Senior Software Engineer");
		designationList.add("Team Lead");
		designationList.add("Manager");
		
	}
	
	@RequestMapping("/welcome.do")
	public ModelAndView getLoginPage(){
	ModelAndView model = new ModelAndView("welcome");
	return model;
    }
	
	@RequestMapping("/getEmployeeForm.do")
	public ModelAndView getEmployeeForm(){
	ModelAndView model = new ModelAndView("employeeForm");
	model.addObject("employee",new Employee());
	model.addObject("designations",designationList);
	return model;
    }

	@RequestMapping("/submitEmployeeForm.do")
		public ModelAndView submitEmployeeform(@ModelAttribute("employee") @Valid Employee employee, BindingResult result){
		ModelAndView model=new ModelAndView();
		if(result.hasErrors()){
			System.out.println(result.getAllErrors());
			model.addObject("employee",employee);
			model.setViewName("employeeForm");
			model.addObject("designations",designationList);
			return model;
		}
		try {
			System.out.println(employee);
			Employee employeeResponse = service.addNewEmployee(employee);
			model.setViewName("successInsert");
			model.addObject("employee",employeeResponse);
		} catch (EmpException e) {
			model.setViewName("error");
			model.addObject("errorMsg","Record Insertion failed: "+e.getMessage());
		}
		return model;
	}
	
	@RequestMapping("/showAllEmployees.do")
	public ModelAndView showAllEmployees(){
	ModelAndView model=null;
	List<Employee> emps=new ArrayList<>();
	try{
		emps=service.getAllEmployees();
	model = new ModelAndView("employeesList");
	model.addObject("emps",emps);
	}catch (EmpException e) {
		model = new ModelAndView("error");
		model.addObject("errorMsg",e.getMessage());
		
	}
	return model;
    }
}
