package com.cg.empDir.daos;

import java.util.List;




import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.RollbackException;

import org.springframework.stereotype.Repository;

import com.cg.empDir.entities.Employee;
import com.cg.empDir.exceptions.EmpException;

@Repository("employeeDao")
public class EmployeeDaoImpl implements EmployeeDao {

	
	private EntityManagerFactory factory;
	
	@Resource(name="entityMFactory")
	public void setManager(EntityManagerFactory factory) {
		this.factory = factory;
	}

	@Override
	public Employee addNewEmployee(Employee employee) throws EmpException {
		EntityManager manager=factory.createEntityManager();
		try {
			manager.getTransaction().begin();
			manager.persist(employee);
			manager.getTransaction().commit();
		} catch (RollbackException e) {
			throw new EmpException("Record not committed",e);
		}
		return employee;
	}

	@Override
	public List<Employee> getAllEmployees() throws EmpException {
		EntityManager manager=factory.createEntityManager();
		String query="select e from emp as e";
		Query qry=manager.createQuery(query,Employee.class);
		return qry.getResultList();
	}

}
