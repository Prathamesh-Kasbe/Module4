DROP TABLE EMPLOYEE;

CREATE TABLE employee(employee_code NUMBER PRIMARY KEY, employee_name VARCHAR2(20), employee_gender VARCHAR(10), designation_name VARCHAR2(30), employee_email VARCHAR2(30), employee_phone VARCHAR2(10));

INSERT INTO EMPLOYEE VALUES(hibernate_sequence.NEXTVAL,'pRATS','MALE','HFUF','UYFGUIY','UYHFUIYFG)')
CREATE SEQUENCE hibernate_sequence start with 2000
increment by 1;


DROP SEQUENCE hibernate_sequence

Commit;