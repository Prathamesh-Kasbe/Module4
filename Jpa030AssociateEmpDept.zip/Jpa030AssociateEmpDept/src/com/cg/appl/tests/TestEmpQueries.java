package com.cg.appl.tests;

import java.util.List;
import java.util.function.Consumer;

import com.cg.appl.entities.Dept;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.HrException;
import com.cg.appl.services.HrServices;
import com.cg.appl.services.HrServicesImpl;

public class TestEmpQueries {

	public static void main(String[] args) {
		HrServices services;
		try {
			services = new HrServicesImpl();
			//long start=System.currentTimeMillis();
			//System.out.println(System.currentTimeMillis()-start);
			
			/*List<Emp> empList=services.getEmpOnsal(0, 10000);
			for(Emp emp:empList){
			    System.out.println(emp);
			}*/
			
			/*Emp emp=new Emp();
			emp.setEmpName("uytr");
			emp.setEmpSal(2000f);
			emp=services.admitNewEmp(emp);
			System.out.println(emp);*/
			
			/*List<Emp> empList=services.getEmpForComm();
			for(Emp emp:empList){
			    System.out.println(emp);
			}*/
			
			Emp emp=services.getEmpDetails(7839);   //getting dept no from emp no
			//Dept dept=services.getDeptDetails(emp.getDeptId());
	        //System.out.println(emp);
	        System.out.println(emp.getDept().getDeptName());
	        System.out.println("*****************");
			
	        Dept dept=services.getDeptDetails(30);   //getting emp list of dept no 30
	        for(Emp emp1:dept.getEmps()){
	        System.out.println(emp1);
	        }
	        
	        //services.getDeptList(deptId);
			
			}catch (HrException e) {
			e.printStackTrace();
		}
	}

}
