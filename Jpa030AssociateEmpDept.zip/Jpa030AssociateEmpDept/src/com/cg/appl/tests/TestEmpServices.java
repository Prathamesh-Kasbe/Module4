package com.cg.appl.tests;

import java.util.List;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.HrException;
import com.cg.appl.services.HrServices;
import com.cg.appl.services.HrServicesImpl;

public class TestEmpServices {

	public static void main(String[] args) {
		HrServices services;
		try {
			services = new HrServicesImpl();
			/*Emp emp=services.getEmpDetails(1112);
	        System.out.println(emp);*/
			
			/*List<Emp> empList=services.getEmpList();
			for(Emp emp:empList){
			System.out.println(emp);
			}*/
			
		/*	Emp emp=new Emp();
			emp.setEmpNo(1112);
			emp.setEmpName("bbbbb");
			emp.setEmpSal(5000f);
			services.admitNewEmp(emp);*/
			/*System.out.println("1st "+ services.getEmpDetails(7499));
			System.out.println("2nd "+services.getEmpDetails(7499));*/
			
			//services.updateName(1112, "dddd");
			
			/*Emp emp=new Emp();
			emp.setEmpNo(1112);
			emp.setEmpName("bbbb");
			emp.setEmpSal(6000f);
			services.updateName(emp);*/
			
			/*services.deleteEmp(1112);
			System.out.println(services.getEmpDetails(1111));*/
			
			
		} catch (HrException e) {
			e.printStackTrace();
		}
        
	}

}
