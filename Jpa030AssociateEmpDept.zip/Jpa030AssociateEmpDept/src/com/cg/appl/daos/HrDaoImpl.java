package com.cg.appl.daos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.RollbackException;
import javax.persistence.TypedQuery;

import com.cg.appl.entities.Dept;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.HrException;
import com.cg.appl.util.EntityManageUtil;

public class HrDaoImpl implements HrDao {
    private EntityManageUtil util;
    private EntityManager manager;
	public HrDaoImpl() throws HrException{
		util= new EntityManageUtil();
		manager=util.getManager();
	}
	
	
	private Emp getEmpDetails(int empNo) throws HrException {
		Emp emp=manager.find(Emp.class,empNo);
		if(emp==null){
			throw new HrException("Wrong EmpNo");
		}
		return emp;
	}
	
	@Override
	public Emp getEmpDetailsSafe(int empNo) throws HrException {
		Emp emp=manager.find(Emp.class,empNo);
		if(emp==null){
			throw new HrException("Wrong EmpNo");
		}
		manager.detach(emp);
		return emp;
	}
	
	@Override
	public List<Emp> getEmpList() throws HrException {
		try {
			//Query qry=manager.createQuery("select e from employee as e");
			Query qry=manager.createNamedQuery("qryAllEmps",Emp.class);
			List<Emp> empList=new ArrayList<>();
			empList=qry.getResultList();
			return empList;
		} catch (Exception e) {
			throw new HrException("Improper query fabrication",e);
		}
	}
	
	/*@Override
	public Emp admitNewEmp(Emp emp) throws EmpException {
		try {
			manager.getTransaction().begin();
			manager.persist(emp);
			manager.getTransaction().commit();
			return emp;
		} catch (RollbackException e) {
			throw new EmpException("Violated: Column size or constraint",e);
		}
	}
	
	@Override
	public boolean updateName(int empNo, String newName) throws EmpException {
		try {
			manager.getTransaction().begin();
			Emp emp=this.getEmpDetails(empNo);
			emp.setEmpName(newName);
			manager.getTransaction().commit();
			return true;
		} catch (RollbackException e) {
			throw new EmpException("Failed: Name updation",e);
		}
	}

	@Override
	public boolean updateName(Emp emp) throws EmpException {
		try {
			manager.getTransaction().begin();
			manager.merge(emp);
			System.out.println("*********");
			manager.getTransaction().commit();
			return true;
		} catch (RollbackException e) {
			throw new EmpException("Failed: Name updation",e);
		}
	}
	
@Override
	public boolean deleteEmp(int empNo) throws EmpException {
	try {
		manager.getTransaction().begin();
		Emp emp=this.getEmpDetails(empNo);
		manager.remove(emp);
		manager.getTransaction().commit();
		return true;
	} catch (RollbackException|EmpException e) {
		throw new EmpException("Failed: record deletion",e);
	}
	}*/

    @Override
	public List<Emp> getEmpOnsal(float from, float to) throws HrException {
		//String qryStr="select e from employee e where empSal between ? and ?";
    	//String qryStr="select e from employee e where empSal between :from and :to";
    	TypedQuery<Emp> qry=manager.createNamedQuery("qryEmpOnSal", Emp.class);
    	qry.setParameter("from", from);
    	qry.setParameter("to", to);
    	return qry.getResultList();
	}

	@Override
	public List<Emp> getEmpForComm() throws HrException {
		TypedQuery<Emp> qry=manager.createNamedQuery("qryEmpComm", Emp.class);
		return qry.getResultList();
	}

	@Override
	public Dept getDeptDetails(int deptId) throws HrException {
		Dept dept=manager.find(Dept.class, deptId);
		if(dept==null){
			throw new HrException("Wrong Department id");
		}
		return dept;
	}
	
	@Override
	protected void finalize() throws Throwable {
		util.closeFactory();
		super.finalize();
	}
}
