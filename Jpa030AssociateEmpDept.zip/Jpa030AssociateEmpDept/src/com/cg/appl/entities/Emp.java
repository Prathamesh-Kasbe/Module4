package com.cg.appl.entities;
import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity(name="employee")
@Table(name="EMP")
@NamedQueries({@NamedQuery(name="qryEmpOnSal",query="select e from employee e where empSal between :from and :to"),
@NamedQuery(name="qryAllEmps",query="select e from employee as e"),
@NamedQuery(name="qryEmpComm",query="select e from employee e where commission is not null")
})
@SequenceGenerator(name="emp_generate", sequenceName="EMP_SEQ", allocationSize=1, initialValue=1)

public class Emp implements Serializable{
	
	private int empNo;
    private String empName;
    private Float empSal;
    private Float commission;
    private Float totalSalary;
    //private Integer deptId;
    
    //Association one-to-one
    private Dept dept;
    @Id
    @GeneratedValue(generator="emp_generate", strategy=GenerationType.SEQUENCE)
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	
	@Column(name="ENAME")
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	
	@Column(name="SAL")
	public Float getEmpSal() {
		return empSal;
	}
	public void setEmpSal(Float empSal) {
		this.empSal = empSal;
	}
	
	@Column(name="COMM")
	public Float getCommission() {
		return commission;
	}
	public void setCommission(Float commission) {
		this.commission = commission;
	}
	//@Column(name="SAL+COMM")
	@Transient
	public Float getTotalSalary() {
	
		return getEmpSal()+(getCommission()!=null?getCommission():0);
	}
	/*public void setTotalSalary(Float totalSalary) {
		this.totalSalary = totalSalary;
	}*/
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="DEPTNO")
	public Dept getDept() {       //this is ownership property
		return dept;
	}
	public void setDept(Dept dept) {
		this.dept = dept;
	}
	@Override
	public String toString() {
		return "Emp [empNo=" + empNo + ", empName=" + empName + ", empSal="
				+ empSal + ", commission=" + commission + ", totalSalary="
				+ totalSalary + ", dept=" + dept + "]";
	}
	
	/*@Column(name="DEPTNO")
	public Integer getDeptId() {
		return deptId;
	}
	public void setDeptId(Integer deptId) {
		this.deptId = deptId;
	}*/
	
	
	
	
}
