package com.cg.appl.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity(name="dept")
@Table(name="DEPT1")
public class Dept implements Serializable{
	@Id
	@Column(name="DEPTID")
	private int deptId;
	
	@Column(name="DEPTNAME")
	private String deptName;
	
	@OneToMany(mappedBy="dept")  //Name of ownership property i.e. join column property
	private List<Emp> emps;
	
	public List<Emp> getEmps() {
		return emps;
	}
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	@Override
	public String toString() {
		return "Dept [deptId=" + deptId + ", deptName=" + deptName + "]";
	}
	
	
}
