package com.cg.appl.services;

import java.util.List;

import com.cg.appl.daos.HrDao;
import com.cg.appl.daos.HrDaoImpl;
import com.cg.appl.entities.Dept;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.HrException;

public class HrServicesImpl implements HrServices {

	private HrDao dao;
	public HrServicesImpl() throws HrException {
		dao=new HrDaoImpl();
	}
	@Override
	public Emp getEmpDetails(int empNo) throws HrException {
		return dao.getEmpDetailsSafe(empNo);
	}
	@Override
	public List<Emp> getEmpList() throws HrException {
		return dao.getEmpList();
	}
	/*@Override
	public Emp admitNewEmp(Emp emp) throws EmpException {
		return dao.admitNewEmp(emp);
	}
	@Override
	public boolean updateName(int empNo, String newName) throws EmpException {
		return dao.updateName(empNo,newName);
	}
	@Override
	public boolean updateName(Emp emp) throws EmpException {
		return dao.updateName(emp);
	}
	@Override
	public boolean deleteEmp(int empNo) throws EmpException {
		return dao.deleteEmp(empNo);
	}*/
	@Override
	public List<Emp> getEmpOnsal(float from, float to) throws HrException {
		return dao.getEmpOnsal(from,to);
	}
	@Override
	public List<Emp> getEmpForComm() throws HrException {
		return dao.getEmpForComm();
	}
	@Override
	public Dept getDeptDetails(int deptId) throws HrException {
		return dao.getDeptDetails(deptId);
	}

}
