package com.cg.appl.services;

import java.util.List;

import com.cg.appl.entities.Dept;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.HrException;

public interface HrServices {

	Emp getEmpDetails(int empNo) throws HrException;
	
	List<Emp> getEmpList()throws HrException;
	
	/*Emp admitNewEmp(Emp emp)throws EmpException;
	
	boolean updateName(int empNo,String newName)throws EmpException;
	
	boolean updateName(Emp emp) throws EmpException;
	
	boolean deleteEmp(int empNo) throws EmpException;*/
	
	List<Emp> getEmpOnsal(float from,float to)throws HrException;
	
	List<Emp> getEmpForComm()throws HrException;
	
	Dept getDeptDetails(int deptId)throws HrException;
}
