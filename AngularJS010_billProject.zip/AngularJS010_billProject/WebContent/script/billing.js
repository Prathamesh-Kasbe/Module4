var billModule = angular.module("billModule",[]);   //place to set the dependency

billModule.controller("billController",
	function($scope){
		$scope.billItem = {
			'qty' : 0,
			'cost' : 0,
			'discount' : 0
		};
		$scope.calcBill = function(){
			return $scope.billItem.qty * $scope.billItem.cost;
		};
		
		$scope.calcDiscount = function(){
			return ($scope.calcBill() * $scope.billItem.discount)/100;
		};
		
		$scope.calcNetBill = function(){
			return $scope.calcBill()-$scope.calcDiscount() ;
		};
	}
);