var userModule = angular.module("userModule",[]);   //place to set the dependency

userModule.controller("usersController",
	function($scope){
		$scope.users = [
						{
							'userId'   : '',
							'userName' : ''
						  }
						];
	}
);

userModule.controller("userController",
			function($scope){
				$scope.user={
						'userId'   : '',
						'userName' : 'Name Please'
				};
			}
);